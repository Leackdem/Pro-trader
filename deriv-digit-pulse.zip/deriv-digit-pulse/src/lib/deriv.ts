export type Market = { symbol: string; name: string };

export const MARKETS: Market[] = [
  { symbol: "R_10", name: "Volatility 10 Index" },
  { symbol: "1HZ10V", name: "Volatility 10 (1s) Index" },
  { symbol: "R_25", name: "Volatility 25 Index" },
  { symbol: "1HZ25V", name: "Volatility 25 (1s) Index" },
  { symbol: "R_50", name: "Volatility 50 Index" },
  { symbol: "1HZ50V", name: "Volatility 50 (1s) Index" },
  { symbol: "R_75", name: "Volatility 75 Index" },
  { symbol: "1HZ75V", name: "Volatility 75 (1s) Index" },
  { symbol: "R_100", name: "Volatility 100 Index" },
  { symbol: "1HZ100V", name: "Volatility 100 (1s) Index" },
  { symbol: "BOOM500", name: "Boom 500 Index" },
  { symbol: "BOOM1000", name: "Boom 1000 Index" },
  { symbol: "CRASH500", name: "Crash 500 Index" },
  { symbol: "CRASH1000", name: "Crash 1000 Index" },
  { symbol: "JD10", name: "Jump 10 Index" },
  { symbol: "JD25", name: "Jump 25 Index" },
  { symbol: "JD100", name: "Jump 100 Index" },
];

export const TICK_OPTIONS = [25, 50, 100, 250, 500, 1000, 2500, 5000] as const;

export const DEFAULT_SYMBOL = "1HZ10V";
export const DEFAULT_TICKS = 1000;

export const DERIV_WS_URL = "wss://ws.derivws.com/websockets/v3?app_id=1089";

/** Maximum ticks retained in the rolling buffer. */
export const MAX_BUFFER = 5000;

/** Last decimal digit of a quote, respecting the market's pip size. */
export function lastDigit(quote: number, pipSize: number): number {
  const fixed = quote.toFixed(pipSize);
  return Number(fixed[fixed.length - 1]);
}

export function isValidSymbol(symbol: string): boolean {
  return MARKETS.some((m) => m.symbol === symbol);
}

export function isValidTicks(ticks: number): boolean {
  return (TICK_OPTIONS as readonly number[]).includes(ticks);
}