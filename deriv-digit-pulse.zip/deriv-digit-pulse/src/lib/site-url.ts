/**
 * Origin used when generating embeddable widget URLs.
 *
 * Priority:
 *  1. VITE_PUBLIC_SITE_URL — set this to your own domain (e.g. on Vercel:
 *     https://your-project.vercel.app) so copied snippets are portable.
 *  2. The browser's current origin.
 */
export function getSiteOrigin(): string {
  const configured = import.meta.env["VITE_PUBLIC_SITE_URL"] as string | undefined;
  if (configured && configured.trim()) return configured.trim().replace(/\/+$/, "");
  if (typeof window !== "undefined") return window.location.origin;
  return "";
}