import { useEffect, useState } from "react";
import {
  DERIV_WS_URL,
  MAX_BUFFER,
  lastDigit,
} from "@/lib/deriv";

export type Tick = { quote: number; digit: number; epoch: number };
export type StreamStatus = "connecting" | "live" | "reconnecting" | "error";

export type DigitStream = {
  status: StreamStatus;
  price: string | null;
  pipSize: number;
  ticks: Tick[];
  counts: number[];
  percentages: number[];
  lastDigitValue: number | null;
  totalSampled: number;
  updateSeq: number;
};

/**
 * Subscribes to Deriv live ticks for `symbol` and derives the last-digit
 * distribution over a rolling window of `windowSize` ticks.
 */
export function useDigitStream(symbol: string, windowSize: number): DigitStream {
  const [status, setStatus] = useState<StreamStatus>("connecting");
  const [pipSize, setPipSize] = useState(2);
  const [buffer, setBuffer] = useState<Tick[]>([]);
  const [updateSeq, setUpdateSeq] = useState(0);

  useEffect(() => {
    let disposed = false;
    let socket: WebSocket | null = null;
    let reconnectTimer: ReturnType<typeof setTimeout> | undefined;
    let pollTimer: ReturnType<typeof setInterval> | undefined;
    let pip = 2;
    let lastEpoch = 0;

    const append = (incoming: Tick[]) => {
      const fresh = incoming.filter((t) => t.epoch > lastEpoch);
      const newestFresh = fresh[fresh.length - 1];
      if (!newestFresh) return;
      lastEpoch = newestFresh.epoch;
      setBuffer((prev) => {
        const next = [...prev, ...fresh];
        return next.length > MAX_BUFFER ? next.slice(next.length - MAX_BUFFER) : next;
      });
      setUpdateSeq((n) => n + 1);
    };

    const connect = () => {
      if (disposed) return;
      setBuffer([]);
      lastEpoch = 0;
      socket = new WebSocket(DERIV_WS_URL);
      const ws = socket;

      const requestHistory = (count: number, subscribe: boolean) =>
        ws.send(
          JSON.stringify({
            ticks_history: symbol,
            count,
            end: "latest",
            style: "ticks",
            ...(subscribe ? { subscribe: 1 } : { req_id: 2 }),
          }),
        );

      ws.onopen = () => {
        setStatus("live");
        requestHistory(MAX_BUFFER, true);
      };

      ws.onmessage = (event) => {
        const msg = JSON.parse(event.data as string);

        // Subscription rejected (e.g. rate limited) -> fall back to polling.
        if (msg.error) {
          if (pollTimer) {
            setStatus("error");
          } else {
            requestHistory(MAX_BUFFER, false);
            pollTimer = setInterval(() => {
              if (ws.readyState === WebSocket.OPEN) requestHistory(30, false);
            }, 1000);
          }
          return;
        }

        if (msg.msg_type === "history" && msg.history) {
          pip = msg.pip_size ?? pip;
          setPipSize(pip);
          const prices: number[] = msg.history.prices.map(Number);
          const times: number[] = msg.history.times.map(Number);
          const history: Tick[] = prices.map((quote, i) => ({
            quote,
            digit: lastDigit(quote, pip),
            epoch: times[i] ?? 0,
          }));
          if (lastEpoch === 0) {
            lastEpoch = history[history.length - 1]?.epoch ?? 0;
            setBuffer(history);
            setUpdateSeq((n) => n + 1);
          } else {
            append(history);
          }
          setStatus("live");
          return;
        }

        if (msg.msg_type === "tick" && msg.tick) {
          pip = msg.tick.pip_size ?? pip;
          setPipSize(pip);
          const quote = Number(msg.tick.quote);
          append([{ quote, digit: lastDigit(quote, pip), epoch: Number(msg.tick.epoch) }]);
          setStatus("live");
        }
      };

      ws.onclose = () => {
        if (disposed) return;
        if (pollTimer) {
          clearInterval(pollTimer);
          pollTimer = undefined;
        }
        setStatus("reconnecting");
        reconnectTimer = setTimeout(connect, 2000);
      };

      ws.onerror = () => {
        if (!disposed) setStatus("reconnecting");
      };
    };

    connect();

    return () => {
      disposed = true;
      if (reconnectTimer) clearTimeout(reconnectTimer);
      if (pollTimer) clearInterval(pollTimer);
      try {
        socket?.close();
      } catch {
        /* noop */
      }
    };
  }, [symbol]);

  const windowed =
    buffer.length > windowSize ? buffer.slice(buffer.length - windowSize) : buffer;

  const counts = Array<number>(10).fill(0);
  for (const tick of windowed) counts[tick.digit] = (counts[tick.digit] ?? 0) + 1;

  const totalSampled = windowed.length;
  const percentages = counts.map((c) => (totalSampled ? (c / totalSampled) * 100 : 0));
  const latest = windowed[windowed.length - 1];

  return {
    status,
    price: latest ? latest.quote.toFixed(pipSize) : null,
    pipSize,
    ticks: windowed,
    counts,
    percentages,
    lastDigitValue: latest ? latest.digit : null,
    totalSampled,
    updateSeq,
  };
}