import { useState } from "react";
import { Link } from "react-router-dom";

import { useDocumentMeta } from "@/hooks/useDocumentMeta";

import { DigitRing } from "@/components/DigitRing";
import { SelectChevron } from "@/components/SelectChevron";
import { useDigitStream } from "@/hooks/useDigitStream";
import { DEFAULT_SYMBOL, DEFAULT_TICKS, MARKETS, TICK_OPTIONS } from "@/lib/deriv";

const TITLE = "Live Deriv Digit Distribution Analysis";
const DESCRIPTION =
  "Real-time last-digit distribution and frequency analysis for Deriv synthetic indices. Analytics only — no trade execution, no predictions.";


const selectClass =
  "w-full appearance-none rounded-lg border border-input bg-panel px-3 py-2.5 pr-9 font-mono text-sm text-foreground outline-none transition focus:border-primary focus:ring-2 focus:ring-ring/30";

export default function DashboardPage() {
  useDocumentMeta(TITLE, DESCRIPTION);

  const [symbol, setSymbol] = useState<string>(DEFAULT_SYMBOL);
  const [ticks, setTicks] = useState<number>(DEFAULT_TICKS);
  const stream = useDigitStream(symbol, ticks);

  const market = MARKETS.find((m) => m.symbol === symbol);
  const sampled = stream.totalSampled > 0;
  const maxPct = sampled ? Math.max(...stream.percentages) : 0;
  const maxDigit = sampled ? stream.percentages.indexOf(maxPct) : -1;
  const minPct = sampled ? Math.min(...stream.percentages) : 0;
  const minDigit = sampled ? stream.percentages.indexOf(minPct) : -1;
  const evenPct = stream.percentages
    .filter((_, i) => i % 2 === 0)
    .reduce((sum, p) => sum + p, 0);

  const recent = stream.ticks.slice(-24).reverse();
  const lastTwo = stream.ticks.slice(-2);
  const direction =
    lastTwo.length < 2
      ? "flat"
      : lastTwo[1]!.quote > lastTwo[0]!.quote
        ? "up"
        : lastTwo[1]!.quote < lastTwo[0]!.quote
          ? "down"
          : "flat";

  const statusLabel =
    stream.status === "live"
      ? "Live feed"
      : stream.status === "error"
        ? "Feed error"
        : stream.status === "reconnecting"
          ? "Reconnecting"
          : "Connecting";

  return (
    <main className="grid-lines min-h-screen px-4 py-8 sm:px-6 lg:px-10">
      <div className="mx-auto max-w-5xl">
        <header className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <p className="label-caps">Deriv market analytics</p>
            <h1 className="mt-1 font-display text-2xl font-semibold tracking-tight sm:text-3xl">
              Digit Distribution Analysis
            </h1>
          </div>
          <div className="flex items-center gap-2 rounded-full border border-border bg-panel px-3 py-1.5">
            <span
              className={`size-2 rounded-full ${
                stream.status === "live"
                  ? "bg-success pulse-dot"
                  : stream.status === "error"
                    ? "bg-destructive"
                    : "bg-warning pulse-dot"
              }`}
            />
            <span className="font-mono text-xs text-muted-foreground">{statusLabel}</span>
          </div>
        </header>

        <section className="panel-glass mt-6 rounded-2xl p-5 sm:p-7">
          <div className="flex flex-wrap items-start justify-between gap-6">
            <div className="min-w-[240px] flex-1">
              <p className="label-caps">Selected market</p>
              <div className="relative mt-2 max-w-xs">
                <select
                  className={selectClass}
                  value={symbol}
                  onChange={(e) => setSymbol(e.target.value)}
                  aria-label="Selected market"
                >
                  {MARKETS.map((m) => (
                    <option key={m.symbol} value={m.symbol}>
                      {m.name}
                    </option>
                  ))}
                </select>
                <SelectChevron />
              </div>
              <p className="mt-2 font-mono text-xs tracking-widest text-muted-foreground">
                {market?.symbol ?? symbol}
              </p>
            </div>

            <div className="text-right">
              <p className="label-caps">Current price</p>
              <div className="mt-2 flex items-center justify-end gap-2">
                <span
                  className={`inline-flex items-center rounded-md px-1.5 py-0.5 font-mono text-sm font-semibold ${
                    direction === "up"
                      ? "bg-success/15 text-success"
                      : direction === "down"
                        ? "bg-destructive/15 text-destructive"
                        : "bg-muted text-muted-foreground"
                  }`}
                  aria-label={
                    direction === "up"
                      ? "Price moved up"
                      : direction === "down"
                        ? "Price moved down"
                        : "Price unchanged"
                  }
                >
                  {direction === "up" ? "▲" : direction === "down" ? "▼" : "—"}
                </span>
                <p className="font-mono text-3xl font-semibold tabular-nums text-primary sm:text-4xl">
                  {stream.price ?? "—"}
                </p>
              </div>
              <p className="mt-1 font-mono text-xs text-muted-foreground">
                Last digit{" "}
                <span className="text-foreground">
                  {stream.lastDigitValue === null ? "—" : stream.lastDigitValue}
                </span>
              </p>
            </div>

            <div className="w-28">
              <p className="label-caps">Ticks</p>
              <div className="relative mt-2">
                <select
                  className={selectClass}
                  value={ticks}
                  onChange={(e) => setTicks(Number(e.target.value))}
                  aria-label="Tick sample size"
                >
                  {TICK_OPTIONS.map((t) => (
                    <option key={t} value={t}>
                      {t}
                    </option>
                  ))}
                </select>
                <SelectChevron />
              </div>
              <p className="mt-2 font-mono text-xs text-muted-foreground">
                {stream.totalSampled} sampled
              </p>
            </div>
          </div>

          <div className="mt-8 border-t border-border pt-7">
            <div className="flex items-baseline justify-between">
              <p className="label-caps">Live digit distribution</p>
              <p className="font-mono text-[0.65rem] text-muted-foreground">
                rolling window · last {ticks} ticks
              </p>
            </div>
            <div className="mt-5 grid grid-cols-5 justify-items-center gap-x-2 gap-y-6 sm:gap-x-4">
              {stream.percentages.map((pct, digit) => (
                <DigitRing
                  key={digit}
                  digit={digit}
                  percentage={pct}
                  count={stream.counts[digit] ?? 0}
                  isMax={digit === maxDigit && sampled}
                  isMin={digit === minDigit && sampled}
                  isLatest={digit === stream.lastDigitValue}
                  seq={stream.updateSeq}
                />
              ))}
            </div>
          </div>

          <div className="mt-8 grid gap-3 sm:grid-cols-4">
            <StatCard
              label="Most frequent"
              value={maxDigit >= 0 ? `${maxDigit}` : "—"}
              sub={`${maxPct.toFixed(1)}%`}
            />
            <StatCard
              label="Least frequent"
              value={minDigit >= 0 ? `${minDigit}` : "—"}
              sub={`${minPct.toFixed(1)}%`}
            />
            <StatCard
              label="Even digits"
              value={`${evenPct.toFixed(1)}%`}
              sub={`odd ${(100 - evenPct).toFixed(1)}%`}
            />
            <StatCard label="Window size" value={`${ticks}`} sub="ticks analysed" />
          </div>
        </section>

        <section className="panel-glass mt-5 rounded-2xl p-5 sm:p-6">
          <p className="label-caps">Recent ticks</p>
          <div className="mt-3 flex flex-wrap gap-1.5">
            {recent.length === 0 && (
              <span className="font-mono text-xs text-muted-foreground">Waiting for ticks…</span>
            )}
            {recent.map((tick, i) => (
              <span
                key={`${tick.epoch}-${i}`}
                className={`grid size-8 place-items-center rounded-md border font-mono text-xs ${
                  i === 0
                    ? "border-primary bg-primary/15 text-primary"
                    : "border-border bg-panel text-muted-foreground"
                }`}
                title={tick.quote.toFixed(stream.pipSize)}
              >
                {tick.digit}
              </span>
            ))}
          </div>
        </section>

        <div className="mt-6 text-center">
          <Link
            to="/embed"
            className="inline-flex items-center rounded-lg border border-border bg-panel px-4 py-2 font-mono text-xs text-primary transition hover:border-primary"
          >
            Get embed widget code →
          </Link>
        </div>

        <p className="mx-auto mt-6 max-w-3xl text-center text-xs leading-relaxed text-muted-foreground">
          Analytics and visualization only. This tool does not place trades and makes no
          predictions — past digit frequencies do not indicate future outcomes. Highlighted digits
          simply mark the highest observed frequency in the selected window.
        </p>
      </div>
    </main>
  );
}

function StatCard({ label, value, sub }: { label: string; value: string; sub: string }) {
  return (
    <div className="rounded-xl border border-border bg-panel/70 px-4 py-3">
      <p className="label-caps">{label}</p>
      <p className="mt-1 font-mono text-lg font-semibold tabular-nums">{value}</p>
      <p className="font-mono text-[0.65rem] text-muted-foreground">{sub}</p>
    </div>
  );
}
