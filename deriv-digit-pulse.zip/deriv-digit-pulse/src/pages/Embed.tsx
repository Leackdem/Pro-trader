import { useEffect, useState } from "react";
import { Link } from "react-router-dom";

import { useDocumentMeta } from "@/hooks/useDocumentMeta";

import { DEFAULT_SYMBOL, DEFAULT_TICKS, MARKETS, TICK_OPTIONS } from "@/lib/deriv";
import { getSiteOrigin } from "@/lib/site-url";

const TITLE = "Embed the Digit Distribution Widget";
const DESCRIPTION =
  "Generate a ready-to-paste iframe snippet for the live Deriv digit distribution widget. Choose market, tick window, and visitor controls.";


const selectClass =
  "w-full appearance-none rounded-lg border border-input bg-panel px-3 py-2.5 font-mono text-sm text-foreground outline-none focus:border-primary";

export default function EmbedPage() {
  useDocumentMeta(TITLE, DESCRIPTION);

  const [symbol, setSymbol] = useState<string>(DEFAULT_SYMBOL);
  const [ticks, setTicks] = useState<number>(DEFAULT_TICKS);
  const [showControls, setShowControls] = useState(true);
  const [origin, setOrigin] = useState("");
  const [copied, setCopied] = useState(false);

  // Resolved on the client so the snippet always points at the deployed domain.
  useEffect(() => {
    setOrigin(getSiteOrigin());
  }, []);

  const widgetUrl = `${origin}/widget?symbol=${symbol}&ticks=${ticks}${
    showControls ? "" : "&controls=false"
  }`;

  const height = showControls ? 420 : 380;
  const snippet = `<iframe
  src="${widgetUrl}"
  title="Live Deriv digit distribution"
  width="100%"
  height="${height}"
  style="border:0;border-radius:16px;overflow:hidden"
  loading="lazy"
  allow="autoplay"
></iframe>`;

  return (
    <main className="grid-lines min-h-screen px-4 py-8 sm:px-6 lg:px-10">
      <div className="mx-auto max-w-3xl">
        <header>
          <p className="label-caps">Integration</p>
          <h1 className="mt-1 font-display text-2xl font-semibold tracking-tight sm:text-3xl">
            Embed the widget
          </h1>
          <p className="mt-2 text-sm text-muted-foreground">
            Paste this iframe into any site (Vercel, WordPress, plain HTML). The full dashboard
            link keeps working as before.
          </p>
          <Link to="/" className="mt-3 inline-block font-mono text-xs text-primary underline">
            ← back to dashboard
          </Link>
        </header>

        <section className="panel-glass mt-6 grid gap-4 rounded-2xl p-5 sm:grid-cols-3 sm:p-6">
          <div>
            <p className="label-caps">Market</p>
            <select
              className={`${selectClass} mt-2`}
              value={symbol}
              onChange={(e) => setSymbol(e.target.value)}
              aria-label="Market"
            >
              {MARKETS.map((m) => (
                <option key={m.symbol} value={m.symbol}>
                  {m.name}
                </option>
              ))}
            </select>
          </div>
          <div>
            <p className="label-caps">Ticks</p>
            <select
              className={`${selectClass} mt-2`}
              value={ticks}
              onChange={(e) => setTicks(Number(e.target.value))}
              aria-label="Tick sample size"
            >
              {TICK_OPTIONS.map((t) => (
                <option key={t} value={t}>
                  {t}
                </option>
              ))}
            </select>
          </div>
          <div>
            <p className="label-caps">Visitor controls</p>
            <label className="mt-2 flex items-center gap-2 rounded-lg border border-input bg-panel px-3 py-2.5 font-mono text-sm">
              <input
                type="checkbox"
                checked={showControls}
                onChange={(e) => setShowControls(e.target.checked)}
              />
              show dropdowns
            </label>
          </div>
        </section>

        <section className="panel-glass mt-5 rounded-2xl p-5 sm:p-6">
          <div className="flex items-center justify-between gap-3">
            <p className="label-caps">Embed code</p>
            <button
              onClick={() => {
                void navigator.clipboard.writeText(snippet);
                setCopied(true);
                setTimeout(() => setCopied(false), 1500);
              }}
              className="rounded-md bg-primary px-3 py-1.5 font-mono text-xs font-medium text-primary-foreground hover:bg-primary/90"
            >
              {copied ? "Copied" : "Copy"}
            </button>
          </div>
          <pre className="mt-3 overflow-x-auto rounded-lg border border-border bg-panel p-3 font-mono text-[0.7rem] leading-relaxed text-foreground">
            {snippet}
          </pre>
          <p className="mt-3 font-mono text-xs text-muted-foreground">
            Direct widget link:{" "}
            <a href={widgetUrl} className="text-primary underline">
              {widgetUrl}
            </a>
          </p>
        </section>

        <section className="panel-glass mt-5 rounded-2xl p-5 sm:p-6">
          <p className="label-caps">Live preview</p>
          {origin && (
            <iframe
              src={widgetUrl}
              title="Widget preview"
              className="mt-3 w-full rounded-xl border-0"
              height={height}
            />
          )}
        </section>
      </div>
    </main>
  );
}