import { Link } from "react-router-dom";
import { useDocumentMeta } from "@/hooks/useDocumentMeta";

export default function NotFound() {
  useDocumentMeta("Page not found — Deriv Digit Pulse", "The page you requested does not exist.");
  return (
    <main className="grid-lines grid min-h-screen place-items-center px-4">
      <div className="panel-glass rounded-2xl px-8 py-10 text-center">
        <p className="label-caps">404</p>
        <h1 className="mt-2 font-display text-2xl font-semibold">Page not found</h1>
        <Link to="/" className="mt-4 inline-block font-mono text-xs text-primary underline">
          ← back to dashboard
        </Link>
      </div>
    </main>
  );
}
