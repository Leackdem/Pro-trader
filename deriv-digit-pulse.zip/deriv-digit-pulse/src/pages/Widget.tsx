import { useState } from "react";
import { useSearchParams } from "react-router-dom";

import { useDocumentMeta } from "@/hooks/useDocumentMeta";

import { DigitRing } from "@/components/DigitRing";
import { useDigitStream } from "@/hooks/useDigitStream";
import {
  DEFAULT_SYMBOL,
  DEFAULT_TICKS,
  MARKETS,
  TICK_OPTIONS,
  isValidSymbol,
  isValidTicks,
} from "@/lib/deriv";

const TITLE = "Digit Distribution Widget — Live Deriv Ticks";
const DESCRIPTION =
  "Embeddable live last-digit distribution widget for Deriv synthetic indices. Analytics only, no trade execution.";


const compactSelect =
  "appearance-none rounded-md border border-input bg-panel px-2 py-1.5 pr-7 font-mono text-xs text-foreground outline-none focus:border-primary";

export default function WidgetPage() {
  useDocumentMeta(TITLE, DESCRIPTION);
  const search = useWidgetSearch();
  const [symbol, setSymbol] = useState<string>(search.symbol);
  const [ticks, setTicks] = useState<number>(search.ticks);
  const stream = useDigitStream(symbol, ticks);

  const sampled = stream.totalSampled > 0;
  const maxPct = sampled ? Math.max(...stream.percentages) : 0;
  const maxDigit = sampled ? stream.percentages.indexOf(maxPct) : -1;
  const minPct = sampled ? Math.min(...stream.percentages) : 0;
  const minDigit = sampled ? stream.percentages.indexOf(minPct) : -1;

  return (
    <main className="min-h-screen bg-background p-3">
      <div className="panel-glass rounded-xl p-3 sm:p-4">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <span
              className={`size-2 rounded-full ${
                stream.status === "live"
                  ? "bg-success pulse-dot"
                  : stream.status === "error"
                    ? "bg-destructive"
                    : "bg-warning pulse-dot"
              }`}
            />
            {search.controls ? (
              <div className="relative">
                <select
                  className={compactSelect}
                  value={symbol}
                  onChange={(e) => setSymbol(e.target.value)}
                  aria-label="Market"
                >
                  {MARKETS.map((m) => (
                    <option key={m.symbol} value={m.symbol}>
                      {m.name}
                    </option>
                  ))}
                </select>
              </div>
            ) : (
              <span className="font-mono text-xs text-muted-foreground">
                {MARKETS.find((m) => m.symbol === symbol)?.name ?? symbol}
              </span>
            )}
          </div>

          <div className="flex items-center gap-3">
            <p className="font-mono text-lg font-semibold tabular-nums text-primary">
              {stream.price ?? "—"}
            </p>
            {search.controls && (
              <select
                className={compactSelect}
                value={ticks}
                onChange={(e) => setTicks(Number(e.target.value))}
                aria-label="Tick sample size"
              >
                {TICK_OPTIONS.map((t) => (
                  <option key={t} value={t}>
                    {t}
                  </option>
                ))}
              </select>
            )}
          </div>
        </div>

        <div className="mt-4 grid grid-cols-5 justify-items-center gap-x-2 gap-y-4">
          {stream.percentages.map((pct, digit) => (
            <DigitRing
              key={digit}
              digit={digit}
              percentage={pct}
              count={stream.counts[digit] ?? 0}
              isMax={digit === maxDigit && sampled}
              isMin={digit === minDigit && sampled}
              isLatest={digit === stream.lastDigitValue}
              seq={stream.updateSeq}
            />
          ))}
        </div>

        <p className="mt-3 text-center font-mono text-[0.6rem] text-muted-foreground">
          {stream.totalSampled} ticks · high {maxDigit >= 0 ? maxDigit : "—"} · low{" "}
          {minDigit >= 0 ? minDigit : "—"} · analytics only, no predictions
        </p>
      </div>
    </main>
  );
}
/** Reads and validates ?symbol=&ticks=&controls= from the URL. */
function useWidgetSearch() {
  const [params] = useSearchParams();
  const symbol = params.get("symbol") ?? DEFAULT_SYMBOL;
  const ticks = Number(params.get("ticks") ?? DEFAULT_TICKS);
  const controls = params.get("controls");
  return {
    symbol: isValidSymbol(symbol) ? symbol : DEFAULT_SYMBOL,
    ticks: isValidTicks(ticks) ? ticks : DEFAULT_TICKS,
    controls: controls !== "false" && controls !== "0",
  };
}
