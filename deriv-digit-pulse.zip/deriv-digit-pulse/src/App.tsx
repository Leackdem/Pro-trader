import { BrowserRouter, Route, Routes } from "react-router-dom";

import Dashboard from "@/pages/Dashboard";
import Embed from "@/pages/Embed";
import Widget from "@/pages/Widget";
import NotFound from "@/pages/NotFound";

export default function App() {
  return (
    <BrowserRouter>
      <Routes>
        {/* Original dashboard — unchanged, still at "/" */}
        <Route path="/" element={<Dashboard />} />
        <Route path="/widget" element={<Widget />} />
        <Route path="/embed" element={<Embed />} />
        <Route path="*" element={<NotFound />} />
      </Routes>
    </BrowserRouter>
  );
}
