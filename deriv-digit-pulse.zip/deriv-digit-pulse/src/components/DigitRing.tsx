import { useEffect, useRef, useState } from "react";

export type DigitRingProps = {
  digit: number;
  percentage: number;
  count: number;
  isMax: boolean;
  isMin: boolean;
  isLatest: boolean;
  /** Increments on every stream update; drives the pop animation. */
  seq: number;
};

export function DigitRing({
  digit,
  percentage,
  count,
  isMax,
  isMin,
  isLatest,
  seq,
}: DigitRingProps) {
  const [popping, setPopping] = useState(false);
  const seenSeq = useRef(seq);

  useEffect(() => {
    if (isLatest && seq !== seenSeq.current) {
      setPopping(true);
      const timer = setTimeout(() => setPopping(false), 500);
      seenSeq.current = seq;
      return () => clearTimeout(timer);
    }
    seenSeq.current = seq;
    return undefined;
  }, [seq, isLatest]);

  const arcColor = isMax
    ? "var(--color-primary)"
    : isMin
      ? "var(--color-destructive)"
      : "var(--color-muted-foreground)";
  const ringBorder = isMax
    ? "var(--color-primary)"
    : isMin
      ? "var(--color-destructive)"
      : "var(--color-border)";
  const numberClass = isMax ? "text-primary" : isMin ? "text-destructive" : "text-foreground";

  return (
    <div className="flex flex-col items-center gap-2">
      <div
        className={`relative grid size-16 place-items-center rounded-full sm:size-20 ${
          popping ? "digit-pop" : ""
        }`}
        style={{
          background: `conic-gradient(${arcColor} ${Math.min(percentage * 3.6 * 2.5, 360)}deg, var(--color-muted) 0deg)`,
          padding: "3px",
          border: `1px solid ${ringBorder}`,
        }}
        aria-label={`Digit ${digit}: ${percentage.toFixed(1)} percent, ${count} ticks`}
      >
        <div className="grid size-full place-items-center rounded-full bg-card">
          <span className={`font-mono text-xl leading-none font-semibold sm:text-2xl ${numberClass}`}>
            {digit}
          </span>
          <span className="mt-0.5 font-mono text-[0.6rem] text-muted-foreground sm:text-xs">
            {percentage.toFixed(1)}%
          </span>
        </div>
      </div>
      <span className="font-mono text-[0.6rem] text-muted-foreground">{count}</span>
    </div>
  );
}