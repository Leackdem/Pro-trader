# Deriv Digit Pulse

Live last-digit distribution analytics for Deriv synthetic indices, plus an
embeddable widget. Self-contained React + Vite + TypeScript project, ready to
deploy to Vercel (or any static host).

> Analytics and visualization only. This project does not place trades and makes
> no predictions.

## Routes

| Route     | Purpose                                                                      |
| --------- | ---------------------------------------------------------------------------- |
| `/`       | **Original dashboard** — market selector, tick-window selector, live price, digit rings, statistics, recent ticks. Unchanged. |
| `/widget` | Compact standalone widget, configurable via query parameters. Embeddable.     |
| `/embed`  | Snippet generator — pick a market/tick window and copy a ready-to-paste iframe. |

## Widget query parameters

`/widget?symbol=R_10&ticks=1000&controls=false`

| Param      | Values                                                        | Default   |
| ---------- | ------------------------------------------------------------- | --------- |
| `symbol`   | `R_10`, `1HZ10V`, `R_25`, `1HZ25V`, `R_50`, `1HZ50V`, `R_75`, `1HZ75V`, `R_100`, `1HZ100V`, `BOOM500`, `BOOM1000`, `CRASH500`, `CRASH1000`, `JD10`, `JD25`, `JD100` | `1HZ10V` |
| `ticks`    | `25`, `50`, `100`, `250`, `500`, `1000`, `2500`, `5000`        | `1000`    |
| `controls` | `false` / `0` hides the dropdowns; anything else shows them    | shown     |

Invalid values fall back to the defaults rather than erroring.

## Local development

```bash
npm install
npm run dev      # http://localhost:5173
npm run build    # type-check + production build into dist/
npm run preview  # serve the production build locally
```

Requires Node 20 or newer.

## Deploy to Vercel

1. Download and extract this ZIP.
2. Copy the files into your GitHub repository and push (do **not** commit
   `node_modules/` or `dist/` — `.gitignore` already excludes them).
3. In Vercel, **Add New → Project** and import that repository.
4. Vercel auto-detects Vite from `vercel.json`. Confirm:
   - Framework preset: **Vite**
   - Build command: `npm run build`
   - Output directory: `dist`
   - Install command: `npm install`
5. Click **Deploy**.

After deploying, all three routes work:

- `https://your-project.vercel.app/` — the original dashboard
- `https://your-project.vercel.app/widget?symbol=R_10&ticks=1000&controls=false`
- `https://your-project.vercel.app/embed`

### Optional: pin the embed domain

`/embed` builds snippets from the origin the page is served from, so it already
produces the correct URL on your Vercel domain. If you want it to always emit a
specific domain (useful behind a custom domain or a preview URL), set an
environment variable in **Vercel → Settings → Environment Variables**:

```
VITE_PUBLIC_SITE_URL=https://your-project.vercel.app
```

Then redeploy. See `.env.example`.

## Embedding on another site

```html
<iframe
  src="https://your-project.vercel.app/widget?symbol=R_10&ticks=1000&controls=false"
  width="100%"
  height="600"
  frameborder="0"
  allow="autoplay">
</iframe>
```

`vercel.json` sets `Content-Security-Policy: frame-ancestors *` on `/widget`
and no `X-Frame-Options`, so the widget embeds on any domain. Do not add
`X-Frame-Options: DENY/SAMEORIGIN` — it would block embedding.

## Direct navigation / refresh on sub-routes

`vercel.json` rewrites every path to `/index.html` so client-side routes such as
`/widget` and `/embed` resolve on direct navigation, refresh, and shared links.

## Data source

Public Deriv WebSocket API: `wss://ws.derivws.com/websockets/v3?app_id=1089`.
The app requests `ticks_history` for the selected window, then subscribes to
live ticks. No account, API token, or secret is required. The last digit is
derived as `Number(quote.toFixed(pipSize).slice(-1))`. The tick buffer is
rolling and capped at 5000 entries; the connection auto-reconnects.

## Project structure

```
├── index.html              # HTML shell, fonts, base meta tags
├── package.json
├── vercel.json             # SPA rewrites + iframe-friendly headers
├── vite.config.ts          # React + Tailwind v4 + "@/" alias
├── tsconfig.json
├── .env.example
├── public/                 # favicon, robots.txt
└── src/
    ├── main.tsx            # React entry
    ├── App.tsx             # routes: /, /widget, /embed
    ├── styles.css          # Tailwind v4 theme tokens + utilities
    ├── components/
    │   ├── DigitRing.tsx
    │   └── SelectChevron.tsx
    ├── hooks/
    │   ├── useDigitStream.ts   # Deriv WebSocket + rolling distribution
    │   └── useDocumentMeta.ts
    ├── lib/
    │   ├── deriv.ts            # markets, tick options, digit helpers
    │   └── site-url.ts         # embed origin resolution
    └── pages/
        ├── Dashboard.tsx
        ├── Widget.tsx
        ├── Embed.tsx
        └── NotFound.tsx
```
